print('Aplikacje bazodanowe')

import sys
from os import system, name
from datetime import datetime

from dbutil4 import *


author_surname = 'Baron'
author_name= 'Roksana'

global connection

def print_menu():
    print (30*'-')
    print("  MENU GŁÓWNE - SYSTEM: " + name + 'Autor:' + author_surname + " " + author_name)
    print (30*'-')
    print ("1. Połączenie z bazą danych z logowaniem")
    print ("2. Dodaj pacjenta")
    print ("3. Lista pacjentów")
    print ("4. Modyfikacja danych pacjenta")
    print ("5. Usuwanie danych pacjenta")
    print ("6. Generowanie pliku raportu")
    print ("0. Rozłączenie z bazą danych. Koniec")
    print (30*'-')

def clear():
    if name == 'nt':
        system('cls')
    else:
        system('clear')

loop = True
clear()
print_menu()
while loop:
    choice = input('Wybór opcji [0-6] : ')
    choice = int(choice)

    if choice == 1:
        clear()
        print_menu()
        connection = db_Connect()
    elif choice == 2:
        clear()
        print_menu()
#        
        query_create(connection,author_surname,author_name)
    elif choice == 3:
        clear()
        print_menu()
#     
        query_read(connection)
    elif choice == 4:
        clear()
        print_menu()
#       
        query_update(connection,author_surname,author_name)
    elif choice == 5:
        clear()
        print_menu()
#        
        query_delete(connection,author_surname,author_name)
    elif choice == 6:
        clear()
        print_menu()
#      
        report_generate(connection,author_surname,author_name)
    elif choice == 0:
      db_Disconnect (connection)
      print ("Zakończenie połączenia z bazą danych")
      print ("Koniec...")
      loop = False
      clear()
    else:
      clear()
      print_menu()
      print("Niewłaściwa opcja menu...")