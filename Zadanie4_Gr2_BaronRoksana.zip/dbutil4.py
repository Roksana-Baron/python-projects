import pyodbc
from datetime import datetime

def db_Connect():
  server = '155.158.112.85,1433'
  database = 'bazaib'
  username = input("Podaj login (userib): ")
  password = input("Podaj hasło (userib123#): ")

  try:
    connection = pyodbc.connect(
      'DRIVER={SQL Server}; SERVER='+
      server+';DATABASE='+database+';UID='+username+';PWD='+password)
    cursor = connection.cursor()
    cursor.execute("SELECT @@version;")
    row = cursor.fetchone()
    print(row[0])
    cursor.close()
    print("Nawiązano połączenie...")
    return connection
  except pyodbc.Error as ex:
    print("Błąd logowania ... ")

def db_Disconnect(connection):
  connection.close()
  
def query_create(connection,author_surname,author_name):
    cursor = connection.cursor()
    patient_surname = input("Podaj nazwisko pacjenta: ")
    patient_name = input("Podaj imie pacjenta: ")
    cursor.execute("INSERT INTO t_pacjent_autoid(nazwisko,imie,opis) values(?,?,?)"
                   ,patient_surname,patient_name,author_surname+author_name)
    connection.commit()
    cursor.close()
    query_read(connection)

def query_read(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT id, nazwisko, imie, badanie, data, data_mod ' +
                   'FROM t_pacjent_autoid')
    print(str(cursor.description[0][0])+ ' ' + str(cursor.description[1][0])+ ' ' +
          str(cursor.description[2][0])+ ' ' + str(cursor.description[3][0]))
    for row in cursor:
        print(row)
    cursor.close()
        
def query_update(connection,author_surname,author_name):
    cursor = connection.cursor()
    data_mod=datetime.now()
    cursor.execute("UPDATE t_pacjent_autoid SET data_mod=? WHERE opis= ?"
                   ,data_mod,author_surname+author_name)
    connection.commit()
    cursor.close()
    query_read(connection)
    

def query_delete(connection,author_surname,author_name):
    cursor = connection.cursor()
    cursor.execute("DELETE FROM t_pacjent_autoid WHERE opis=? ", author_surname+author_name)
    connection.commit()
    cursor.close()
    query_read(connection)
    
def report_generate(connection,author_surname,author_name):
    cursor = connection.cursor()
    report_rows=[]
    rows_list=[]
    cursor.execute("SELECT id, nazwisko,imie,badanie,data,data_mod "+
                   "FROM t_pacjent_autoid")
    for row_cursor in cursor:
        row_data = dict(id=row_cursor[0], surname=row_cursor[1], name=row_cursor[2])
        rows_list.append(row_data)
        
    for row_list in rows_list:
        report_rows.append("############ DANE PACJENTA ##################################")
        report_rows.append(str(row_list['id']) +" " +row_list['surname'] +" " +row_list['name'])
        cursor.execute("SELECT w.id, w.opis, w.recepta, w.data_wizyty, w.pacjent_id "+
                   "FROM t_wizyta w WHERE w.pacjent_id = ?", row_list['id'])
        report_rows.append("------------------LISTA WIZYT------------------")
        for row_visit in cursor:
            report_rows.append(row_visit)
        report_rows.append("###############################################################")
        report_rows.append("");
        
    report_rows.append("Dane autora:" + author_surname +"" + author_name)
    report_rows.append("Data wydruku:" + datetime.now().strftime("%Y/%m/%d,%H:%M:%S"))
    
    file_name = 'report' + datetime.now().strftime("%Y.%m.%d_%H.%M.%S") + '.txt'
    file = open(file_name, 'a')
    for report_row in report_rows:
        file.write(str(report_row))
        file.write('\n')
    file.close()
    print("Generowanie raportu zakończenie")
        
        
        
    

    