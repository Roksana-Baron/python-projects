import pyodbc
from datetime import datetime

def db_Connect():
  server = '155.158.112.85,1433'
  database = 'bazaib'
  username = input("Podaj login (userib): ")
  password = input("Podaj hasło (userib123#): ")

  try:
    connection = pyodbc.connect(
      'DRIVER={SQL Server}; SERVER='+ server+';DATABASE='+database+';UID='+username+';PWD='+password)
    cursor = connection.cursor()
    cursor.execute("SELECT @@version;")
    row = cursor.fetchone()
    print(row[0])
    cursor.close()
    print("Nawiązano połączenie...")
    return connection
  except pyodbc.Error as ex:
    print("Błąd logowania ... ")

def db_Disconnect(connection):
  connection.close()
  
def query_2(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT p.id, p.nazwisko, p.imie, w.recepta, w.data_wizyty ' +
                   'FROM t_wizyta w, t_pacjent_autoid p '+
                   'WHERE p.id = w.pacjent_id '+
                   'ORDER BY p.nazwisko')
    for row in cursor:
        print(row)

def query_3(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT l.id, l.nazwisko, l.imie, l.specjalizacja, w.recepta, w.data_wizyty ' +
                   'FROM t_wizyta w, t_lekarz l '+
                   'WHERE l.id = w.lekarz_id '+
                   'ORDER BY l.nazwisko')
    for row in cursor:
        print(row)
    cursor.close()
        
def query_4(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT p.id, p.nazwisko, p.imie, COUNT(*) AS liczba_wizyt_pacjenta ' +
                   'FROM t_wizyta w, t_pacjent_autoid p '+
                   'WHERE p.id = w.pacjent_id '+
                   'GROUP BY p.nazwisko, p.imie, p.id '+
                   'ORDER BY p.nazwisko')
    for row in cursor:
        print(row)
    cursor.close()

def query_5(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT l.id, l.nazwisko, l.imie, COUNT(*) AS liczba_wizyt_lekarza ' +
                   'FROM t_wizyta w, t_lekarz l '+
                   'WHERE l.id = w.lekarz_id '+
                   'GROUP BY l.nazwisko, l.imie, l.id '+
                   'ORDER BY l.nazwisko')
    for row in cursor:
        print(row)
    cursor.close()
    
def query_C(connection,author_surname,author_name):
    cursor = connection.cursor()
    cursor.execute("INSERT INTO t_pacjent_autoid(nazwisko,imie) values (?, ?)"
                   ,author_surname,author_name)
    connection.commit()
    cursor.close()
    query_R(connection)
    
def query_R(connection):
    cursor = connection.cursor()
    cursor.execute('SELECT id, nazwisko, imie, badanie,data,data_mod ' +
                   'FROM t_pacjent_autoid')
    print(str(cursor.description[0][0])+ ' ' + str(cursor.description[1][0])+ ' ' +
          str(cursor.description[2][0])+ ' ' + str(cursor.description[3][0]))
    for row in cursor:
        print(row)
    cursor.close()
    
def query_U(connection,author_surname,author_name):
    cursor = connection.cursor()
    data_mod = datetime.now()
    cursor.execute("UPDATE t_pacjent_autoid SET data_mod = ? WHERE nazwisko = ? AND imie = ?"
                   ,data_mod,author_surname,author_name,)
    connection.commit()
    cursor.close()
    query_R(connection)
    
def query_D(connection,author_surname,author_name):
    cursor = connection.cursor()
    data_mod = datetime.now()
    cursor.execute("DELETE FROM t_pacjent_autoid WHERE nazwisko = ? AND imie = ? ",author_surname, author_name)
    connection.commit()
    cursor.close()
    query_R(connection)
    