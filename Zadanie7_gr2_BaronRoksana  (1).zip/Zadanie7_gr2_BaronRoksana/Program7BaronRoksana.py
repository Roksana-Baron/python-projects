import sys
from datetime import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtSql import QSqlDatabase, QSqlTableModel

from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QMessageBox,
    QLabel,
    QGridLayout,
    QWidget,
    QTableView,
    QPushButton,
    QLineEdit
)

from PyQt5.QtCore import (
    QSortFilterProxyModel
)

from fpdf import FPDF


author_surname = 'Baron'
author_name = 'Roksana'

tableModel = None
tableView = None

def createConnection():
    
    server = '155.158.112.85,1433'
    database = 'bazaib'
    username = 'userib'
    password = 'userib123#'
    
    db = QSqlDatabase.addDatabase('QODBC')
    db.setDatabaseName(f'Driver={{SQL SERVER}}; Server={server}; Database={database}; UID={username}; PWD={password}')
    db.open()
    
    if db.open():
        showMessageFull('Połączono z bazą',QMessageBox.Information)
        return True
    else:
        showMessageFull('Brak połączenia...',QMessageBox.Critical)
        return False
    
def showMessageFull(messageText,messageType):
    msg = QMessageBox()
    msg.setIcon(messageType)
    msg.setText(messageText)
    
    msg.setWindowTitle("Okno komunikatu")
    
    retval = msg.exec_()

    
def refreshModelView():
    #odczyt danych z bazy i prezentacja tabeli
    global tableModel
    tableModel = QSqlTableModel()
    tableModel.setTable("t_pacjent_autoid")
    tableModel.setEditStrategy(QSqlTableModel.OnFieldChange)
    
    tableModel.setHeaderData(0, Qt.Horizontal, "ID")
    tableModel.setHeaderData(1, Qt.Horizontal, "Nazwisko")
    tableModel.setHeaderData(2, Qt.Horizontal, "Imię")
    tableModel.setHeaderData(3, Qt.Horizontal, "Badanie")
    tableModel.setHeaderData(4, Qt.Horizontal, "Data")
    tableModel.setHeaderData(5, Qt.Horizontal, "Data modyfikacji")
    tableModel.setHeaderData(6, Qt.Horizontal, "Opis")
    tableModel.setHeaderData(7, Qt.Horizontal, "Obraz")
    tableModel.setHeaderData(8, Qt.Horizontal, "Data urodzenia")
    tableModel.select()
    
    global tableView
    tableView = QTableView()
    tableView.resizeColumnsToContents()
    
    filterSurname = QSortFilterProxyModel()
    filterSurname.setSourceModel(tableModel)
    filterSurname.setFilterKeyColumn(1)
    
    filterName = QSortFilterProxyModel()
    filterName.setSourceModel(filterSurname)
    filterName.setFilterKeyColumn(2)
    
    surnameLabel = QLabel()
    surnameLabel.setText("Nazwisko")
    layout.addWidget(surnameLabel, 2, 0)
    
    filterSurnameEdit = QLineEdit()
    filterSurnameEdit.textChanged.connect(filterSurname.setFilterRegExp)
    layout.addWidget(filterSurnameEdit, 2, 1)
    
    nameLabel = QLabel()
    nameLabel.setText("Imię")
    layout.addWidget(surnameLabel, 2, 2)
    
    filterNameEdit = QLineEdit()
    filterNameEdit.textChanged.connect(filterName.setFilterRegExp)
    layout.addWidget(filterNameEdit, 2, 3)
    
    tableView.setModel(filterName)
    tableView.setColumnHidden(5, True)
    tableView.setColumnHidden(6, True)
    tableView.setColumnHidden(7, True)
    
    layout.addWidget(tableView, 4, 0, 4, 10)
 
    
def login():
    if not createConnection():
        showMessageFull('Brak połączenia z bazą danych',QMessageBox.Critical)
        sys.exit(1)
    #wczytanie danych do modelu i widoku po poprawnym zalogowaniu
    refreshModelView()
    showMessageFull("Wczytano dane z bazy...",QMessageBox.Information)
    
def logout():
    sys.exit(1)
    
def report():
    #print ("Tutaj będzie uzupełniony kod generowania raportu")
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.add_page()
    
    print("Ladowanie czcionek")
    pdf.add_font('DejaVu', fname='DejaVuSans.ttf', uni=True)
    print("Czcionki załadowane")
    pdf.set_font('DejaVu', size=14)
    print("Czcionki ustawione")
    
    pdf.image("fpdf2-logo.png", 10, 8, 33)
    
    pdf.set_font('DejaVu', size=8)
    
    pdf.set_x(-40)
    pdf.cell(20, 10, "Data wydruku: " + datetime.now().strftime ("%Y.%m.%d"))
    pdf.ln(10)
    pdf.cell(60)
    pdf.set_font('DejaVu', size=16)
    
    pdf.cell(60, 10, "Lista pacjentów", 1, 0, "C")
    pdf.ln(20)
    pdf.set_font('DejaVu', size=12)
    col_names = ['Id', 'Nazwisko', 'Imie', 'Badanie', 'Data', 'Data ur.']
    
    global tableView
    tableModel = tableView.model()
    
    for heading in col_names:
        pdf.cell(30, 7, heading, 1)
    pdf.ln()
    for r in range(tableModel.rowCount()):
        idn = str(tableModel.index(r, 0).data())
        pdf.cell(30, 6, idn, 1)
        
        nazwisko = tableModel.index(r, 1).data()
        pdf.cell(30, 6, nazwisko, 1)
        
        imie = tableModel.index(r, 2).data()
        pdf.cell(30, 6, imie, 1)
        
        badanie = tableModel.index(r, 3).data()
        pdf.cell(30, 6, badanie, 1)
        
        data = tableModel.index(r, 4).data().toString('yyyy.MM.dd')
        pdf.cell(30, 6, data, 1)
        
        data_urodzenia = tableModel.index(r, 8).data()#.toString('yyyy.MM.dd')
        pdf.cell(30, 6, data_urodzenia, 1)
        pdf.ln()
        
    pdf.set_y(-40)
    pdf.set_font('DejaVu', size=8)
    app_ver = "1.0.0"
    pdf.cell(0, 10, "Autor: " + author_surname + " " + author_name)
    pdf.ln(5)
    pdf.cell(0, 10, "Wersja: " + app_ver)
    pdf.cell(0, 10, f"Page {pdf.page_no()}/{{nb}}", 0, 0, "C")
    fileName = 'raport_' + datetime.now().strftime("%Y.%m.%d_%H.%M.%S") + '.pdf'
    pdf.output(fileName)

    
app = QApplication(sys.argv)
window = QMainWindow()
window.setWindowTitle("Zadanie 7: " + author_surname + ' ' + author_name)


window.resize(1024, 600)

#przygotowanie menadzera układu
layout = QGridLayout()

#dodanie napisu etykiety
layout.addWidget(QLabel('Aplikacje bazodanowe'), 0, 0)
layoutWidget = QWidget();
layoutWidget.setLayout(layout);

#dodanie przycisków
pushButtonLogin = QPushButton('Zaloguj')
pushButtonRefresh = QPushButton('Wyloguj')
pushButtonReport = QPushButton('Raport')

pushButtonLogin.clicked.connect(login)
pushButtonRefresh.clicked.connect(logout)
pushButtonReport.clicked.connect(report)

layout.addWidget(pushButtonLogin, 1, 0)
layout.addWidget(pushButtonRefresh, 1, 1)
layout.addWidget(pushButtonReport, 1, 2)

#rozmieszczenie tabeli baz danych
tableView = QTableView()
layout.addWidget(tableView, 4, 0, 4, 10)


window.setCentralWidget(layoutWidget)


window.show()


sys.exit(app.exec_())














